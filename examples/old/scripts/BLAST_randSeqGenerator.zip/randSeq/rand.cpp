#include <fstream>
#include <ctime>
#include <cstdlib>

using namespace std;

int main(int argc, char* argv[]) {
	srand(time(0));
	int a;
	if(argc != 2) {
		return 0;
	}
	else {
		a = atoi(argv[1]);
	}
	
	ofstream file;
	file.open("a2.txt");
	for(int i = 0; i < a; ++i) {
		file << char(rand());
	}
	file.close();
	return 0;
}
